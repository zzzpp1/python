-- 插入记录  
insert into student values('001','张三','18','男')；
-- 修改记录  
update student set age='18' where age='20';
--  删除记录  
delete from student where age='20';
-- 查询记录
select  name from student  